/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjmarcaveiculo.objetos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Registro {
    
    Scanner scan = new Scanner(System.in);
    
    public void cadrastro(Veiculo v){
         
        List<Veiculo> lstveiculo = new ArrayList();

        System.out.println("Digite o tipo do veiculo Ex: carro, moto, barco, helicoptero: ");
        v.setTipo(scan.nextLine());
        System.out.println("Digite o nome do veiculo: ");
        v.setNome(scan.nextLine());
        System.out.println("Digite o modelo do veiculo: ");
        v.setModelo(scan.nextLine());
        System.out.println("Digite o ano de fabricacao: ");
        v.setAno(scan.nextLine());
        
        lstveiculo.add(v);
        
        
    }
    
    public void cadrastro(Marca m){
        
        System.out.println("Digite o nome da marca: ");
        m.setNome(scan.nextLine());
        System.out.println("Razao social: ");
        m.setRazaoSocial(scan.nextLine());
        System.out.println("Cnpj: ");
        m.setCnpj(scan.nextLine());
        System.out.println("Inscricao Estadual: ");
        m.setIncricaoEstadual(scan.nextLine());
               
    }
    
}
