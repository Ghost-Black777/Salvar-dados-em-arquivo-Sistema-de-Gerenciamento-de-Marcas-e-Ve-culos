package com.mycompany.prjmarcaveiculo.objetos;

import java.util.ArrayList;
import java.util.List;

public class Marca {
    private String nome;
    private String razaoSocial;
    private String cnpj;
    private String incricaoEstadual;
    private List<Veiculo> lstveiculo; // lista de veículos da marca

    public Marca() {
        this.lstveiculo = new ArrayList<>(); // evita NullPointerException
    }

    public Marca(String nome, String razaoSocial, String cnpj, String incricaoEstadual) {
        this.nome = nome;
        this.razaoSocial = razaoSocial;
        this.cnpj = cnpj;
        this.incricaoEstadual = incricaoEstadual;
        this.lstveiculo = new ArrayList<>();
    }

    // Getters e Setters
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getRazaoSocial() { return razaoSocial; }
    public void setRazaoSocial(String razaoSocial) { this.razaoSocial = razaoSocial; }

    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { this.cnpj = cnpj; }

    public String getIncricaoEstadual() { return incricaoEstadual; }
    public void setIncricaoEstadual(String incricaoEstadual) { this.incricaoEstadual = incricaoEstadual; }

    public List<Veiculo> getLstveiculo() { return lstveiculo; }
    public void setLstveiculo(List<Veiculo> lstveiculo) { this.lstveiculo = lstveiculo; }

    // Método de conveniência para adicionar veículo
    public void addVeiculo(Veiculo v) {
        this.lstveiculo.add(v);
    }
}
