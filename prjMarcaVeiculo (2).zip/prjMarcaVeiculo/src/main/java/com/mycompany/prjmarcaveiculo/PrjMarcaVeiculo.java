/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjmarcaveiculo;

import com.mycompany.prjmarcaveiculo.menu.MenuPrincipal;


public class PrjMarcaVeiculo {

    public static void main(String[] args) {
        
        MenuPrincipal menuP = new MenuPrincipal();
        menuP.menuPrincipal();
        
    }
}
