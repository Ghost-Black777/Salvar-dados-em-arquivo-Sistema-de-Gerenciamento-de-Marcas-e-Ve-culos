package com.mycompany.prjmarcaveiculo.Util;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author clc
 */
public class EscreverArquivo 
{
    public void escrever(String arquivo, String texto, boolean manter)
    {        
        try 
        {
            /*Define o caminho do arquivo que será 
            utilizado para leitura ou escrita*/
            File f = new File(arquivo);
            /*Cria uma instância do arquivo para escrita*/
            FileWriter fw = new FileWriter(f, manter);
            /*Cria o meio para escrever no arquivo
            instanciado na linha anterior*/
            PrintWriter pw = new PrintWriter(fw);
            //Escreve no arquivo
            pw.println(texto);
            //Conclui a escrita do arquivo
            fw.close();
        } 
        catch (IOException ex) {
            ex.printStackTrace();
        }       
    }
    
}
