package com.mycompany.prjmarcaveiculo.Util;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author clc
 */
public class LerArquivo 
{
    public BufferedReader ler(String arquivo)
    {     
        BufferedReader br = null;
        try 
        {
            /*Define o caminho do arquivo que será 
            utilizado para leitura ou escrita*/
            File f = new File(arquivo);
            /*Cria um instancia do arqui que será lido*/
            FileReader fr = new FileReader(f);
            /*Armazena o conteúdo do arquivo para
            leitura*/
            br = new BufferedReader(fr);
            //Lê todas as linhas que estão escritas no arquivo
        } 
        catch (IOException ex) {
            ex.printStackTrace();
        }    
        return br;
    }
    
}