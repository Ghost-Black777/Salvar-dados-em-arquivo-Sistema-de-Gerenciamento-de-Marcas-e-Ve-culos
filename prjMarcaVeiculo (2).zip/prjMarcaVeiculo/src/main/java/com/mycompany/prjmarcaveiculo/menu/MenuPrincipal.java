/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjmarcaveiculo.menu;

import com.mycompany.prjmarcaveiculo.gerenciar.GerenciarDados;
import com.mycompany.prjmarcaveiculo.objetos.Marca;
import com.mycompany.prjmarcaveiculo.objetos.Registro;
import com.mycompany.prjmarcaveiculo.objetos.Veiculo;
import java.util.Scanner;



public class MenuPrincipal {

    private String nome;
    
   public void menuPrincipal(){
       
       Scanner scan = new Scanner(System.in);
       Registro regi = new Registro();
       Marca marca = new Marca();
       Veiculo veiculo = new Veiculo();
       
       int opcao = 0;
       
       GerenciarDados gd = new GerenciarDados();
       
       while(opcao != 3){
            
           System.out.println(" 'MENU' \n");
           System.out.println("Digite 1 para cadrastrar marca e veiculo\n");
           System.out.println("Digite 2 consultar dados \n");
           System.out.println("Digite 3 para encerrar...\n");     
           opcao = scan.nextInt();
                   
           if(opcao == 1){
                 
               regi.cadrastro(marca);
               regi.cadrastro(veiculo);
               gd.salvarDados(marca);
           }
           if(opcao == 2){
               
               gd.buscarDados(nome);
           }
         
         
       }
       
   }
  
}
