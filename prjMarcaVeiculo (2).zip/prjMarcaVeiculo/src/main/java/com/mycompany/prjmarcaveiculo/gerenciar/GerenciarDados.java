package com.mycompany.prjmarcaveiculo.gerenciar;

import com.mycompany.prjmarcaveiculo.Util.EscreverArquivo;
import com.mycompany.prjmarcaveiculo.Util.LerArquivo;
import com.mycompany.prjmarcaveiculo.objetos.Marca;
import com.mycompany.prjmarcaveiculo.objetos.Veiculo;
import java.io.BufferedReader;
import java.io.IOException;

public class GerenciarDados {
    EscreverArquivo e_arq;
    LerArquivo l_arq;

    public GerenciarDados() {
        e_arq = new EscreverArquivo();
        l_arq = new LerArquivo();
    }

    // -------------------
    // SALVAR DADOS
    // -------------------
    public void salvarDados(Marca m) {
        String arquivo = "c:\\Marca.txt";

        // Salva os dados da Marca (linha com prefixo M)
        String dadosMarca = "M;" + m.getNome() + ";" + m.getRazaoSocial() + ";" 
                + m.getCnpj() + ";" + m.getIncricaoEstadual();
        e_arq.escrever(arquivo, dadosMarca, true);

        // Salva os veículos da Marca (linhas com prefixo V)
        for (Veiculo v : m.getLstveiculo()) {
            String dadosVeiculos = "V;" + v.getNome() + ";" + v.getAno() + ";" 
                    + v.getTipo() + ";" + v.getModelo();
            e_arq.escrever(arquivo, dadosVeiculos, true);
        }
    }

    // -------------------
    // BUSCAR DADOS
    // -------------------
    public void buscarDados(String nome) {
        String arquivo = "c:\\Marca.txt";
        BufferedReader br = l_arq.ler(arquivo);
        lerBuffer(br, nome);
    }

    // -------------------
    // LER BUFFER
    // -------------------
    public void lerBuffer(BufferedReader br, String nomeBuscado) {
        try {
            String linha;
            Marca m = null;

            while ((linha = br.readLine()) != null) {
                String[] partesLinha = linha.split(";");
                String tipo = partesLinha[0].trim();

                if (tipo.equals("M")) {
                    // Cria uma nova Marca
                    m = new Marca();
                    m.setNome(partesLinha[1].trim());
                    m.setRazaoSocial(partesLinha[2].trim());
                    m.setCnpj(partesLinha[3].trim());
                    m.setIncricaoEstadual(partesLinha[4].trim());

                    // Só mostra se for a marca buscada
                    if (m.getNome().equalsIgnoreCase(nomeBuscado)) {
                        mostrarDados(m);
                    }
                } 
                else if (tipo.equals("V") && m != null && m.getNome().equalsIgnoreCase(nomeBuscado)) {
                    // Cria veículo vinculado à marca
                    Veiculo v = new Veiculo();
                    v.setNome(partesLinha[1].trim());
                    v.setAno(partesLinha[2].trim());
                    v.setTipo(partesLinha[3].trim());
                    v.setModelo(partesLinha[4].trim());

                    m.addVeiculo(v); // adiciona na lista já inicializada
                    mostrarDados(v);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // -------------------
    // MOSTRAR VEÍCULO
    // -------------------
    private void mostrarDados(Veiculo v) {
        System.out.println("\n--- Veículo ---");
        System.out.println("Nome: " + v.getNome());
        System.out.println("Modelo: " + v.getModelo());
        System.out.println("Ano: " + v.getAno());
        System.out.println("Tipo: " + v.getTipo());
    }

    // -------------------
    // MOSTRAR MARCA
    // -------------------
    private void mostrarDados(Marca m) {
        System.out.println("\n=== Marca Encontrada ===");
        System.out.println("Nome: " + m.getNome());
        System.out.println("Razão Social: " + m.getRazaoSocial());
        System.out.println("CNPJ: " + m.getCnpj());
        System.out.println("Inscrição Estadual: " + m.getIncricaoEstadual());
    }
}
